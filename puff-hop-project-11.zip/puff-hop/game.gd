extends Node2D
## Puff Hop - a Flappy-style game. Tap / click / Space to hop.
## Everything is drawn in code so there are no art files yet.

const W := 540.0
const H := 960.0
const GROUND_Y := 860.0
const PLAYER_X := 140.0
const RADIUS := 24.0
const GRAVITY := 1500.0
const FLAP := -460.0
const PIPE_W := 90.0
const GAP := 230.0
const PIPE_SPEED := 210.0
const SPAWN_EVERY := 1.45
const PIPE_SPACING := PIPE_SPEED * SPAWN_EVERY   # distance between pipes; stays the same at every level
const SAVE_PATH := "user://save.cfg"
const GHOST_TIME := 4.0        # seconds of ghost mode per pickup
const PICKUP_R := 18.0
const PICKUP_MIN_PIPES := 6    # fewest pipes between power-ups
const PICKUP_CHANCE := 0.35    # chance per pipe once the minimum has passed

# --- Mega power-up: Puff gets bigger, the world speeds up, and pipes get smashed ---
const MEGA_TIME := 5.0         # seconds of Mega mode per pickup
const MEGA_SCALE := 1.7        # how much bigger Puff gets
const MEGA_SPEED := 1.5        # how much faster everything scrolls
const MEGA_END_GRACE := 0.6    # short protection when Mega ends, while Puff shrinks back
const MEGA_SHARE := 0.4        # share of power-up pickups that are Mega (the rest are Ghost)
const MEGA_BANNER_TIME := 1.0
const DEBRIS_GRAVITY := 1400.0

# --- coins & shop (tweak these to balance the economy) ---
const COIN_R := 14.0
const COIN_PATH_POINTS := [0.3, 0.5, 0.7]  # where coins sit between two pipes (0 = this pipe, 1 = next)
const GHOST_PRICE := 40        # price of one "Ghost Start" charge
const MAX_GHOST_CHARGES := 9

# --- levels (tweak these to balance difficulty) ---
const PIPES_PER_LEVEL := 10     # score needed per level
const LEVEL_SPEED_STEP := 12.0  # pipes get this much faster each level...
const MAX_SPEED_BONUS := 90.0   # ...up to this much extra speed
const LEVEL_GAP_STEP := 8.0     # the gap between pipes shrinks this much each level...
const MIN_GAP := 170.0          # ...down to this size
const LEVEL_COIN_BONUS := 5     # coins awarded for reaching a new level
const BANNER_TIME := 1.8

# --- lives (tweak these to balance difficulty) ---
const MAX_LIVES := 3
const INVULN_TIME := 1.5       # seconds of protection after losing a heart
const GHOST_END_GRACE := 0.6   # short protection when ghost mode ends, so you aren't hit while still inside a pipe
const HURT_BOUNCE := -300.0    # little hop when a pipe hits you
const SHAKE_TIME := 0.25
const SHAKE_POWER := 9.0

# --- UI layout ---
const SHOP_BTN := Rect2(170.0, 750.0, 200.0, 64.0)
const BACK_BTN := Rect2(170.0, 815.0, 200.0, 76.0)
const AD_START_BTN := Rect2(90.0, 590.0, 360.0, 60.0)    # start screen: watch ad -> start with +1 heart
const AD_REVIVE_BTN := Rect2(90.0, 625.0, 360.0, 60.0)   # game over screen: watch ad -> continue
const REVIVE_PROTECT := 2.5    # seconds of protection after continuing
const ROW_X := 24.0
const ROW_Y0 := 210.0
const ROW_W := 492.0
const ROW_H := 84.0
const ROW_STEP := 92.0

enum State { READY, PLAYING, DEAD, SHOP }

var state := State.READY
var y := 450.0
var vel := 0.0
var pipes: Array = []
var coin_items: Array = []
var spawn_timer := 0.0
var score := 0
var high_score := 0
var new_best := false
var dead_time := 0.0
var bob_t := 0.0
var ground_scroll := 0.0
var font: Font
var ghost_left := 0.0
var mega_left := 0.0
var mega_s := 1.0            # Puff's current size multiplier (eases to MEGA_SCALE and back)
var mega_mult := 1.0         # current world-speed multiplier (eases to MEGA_SPEED and back)
var mega_banner_t := 0.0
var debris: Array = []       # flying pieces of smashed pipes
var pipes_since_pickup := 0
var next_gap_y := 0.0
var lives := MAX_LIVES
var invuln_left := 0.0
var shake_t := 0.0
var max_lives := MAX_LIVES
var bonus_heart := false     # an ad was watched on the start screen: next run starts with +1 heart
var revive_used := false     # one "watch ad to continue" per run
var level := 1
var speed := PIPE_SPEED      # current pipe speed (rises with level)
var gap := GAP               # current gap size (shrinks with level)
var theme_idx := 0
var banner_t := 0.0
var col_sky := Color(0.55, 0.80, 0.95)
var col_pipe := Color(0.35, 0.75, 0.30)
var col_lip := Color(0.25, 0.60, 0.22)
var col_cloud := Color(1, 1, 1, 0.8)

# saved progress
var coins := 0
var run_coins := 0
var owned: Array = ["bubblegum"]
var equipped := "bubblegum"
var ghost_charges := 0

var toast_text := ""
var toast_t := 0.0
var _sb: StyleBoxFlat

# Skins for Puff. The first one is free and always owned.
var skins: Array = [
	{"id": "bubblegum", "name": "Bubblegum", "price": 0,
		"body": Color(1.0, 0.78, 0.85), "wing": Color(1.0, 0.65, 0.75), "cheek": Color(1.0, 0.55, 0.65)},
	{"id": "sky", "name": "Sky", "price": 50,
		"body": Color(0.62, 0.82, 1.0), "wing": Color(0.48, 0.70, 0.95), "cheek": Color(1.0, 0.60, 0.70)},
	{"id": "sunny", "name": "Sunny", "price": 100,
		"body": Color(1.0, 0.92, 0.50), "wing": Color(1.0, 0.82, 0.35), "cheek": Color(1.0, 0.60, 0.45)},
	{"id": "mint", "name": "Mint", "price": 150,
		"body": Color(0.65, 0.95, 0.78), "wing": Color(0.45, 0.85, 0.65), "cheek": Color(1.0, 0.65, 0.70)},
	{"id": "ember", "name": "Ember", "price": 250,
		"body": Color(1.0, 0.65, 0.40), "wing": Color(0.95, 0.50, 0.30), "cheek": Color(1.0, 0.40, 0.40)},
]


# Look of each level; levels cycle through these (level 1 = Day, 5 = Day again, ...).
var themes: Array = [
	{"sky": Color(0.55, 0.80, 0.95), "pipe": Color(0.35, 0.75, 0.30), "lip": Color(0.25, 0.60, 0.22), "cloud": Color(1, 1, 1, 0.8)},
	{"sky": Color(0.98, 0.66, 0.50), "pipe": Color(0.78, 0.42, 0.30), "lip": Color(0.62, 0.30, 0.22), "cloud": Color(1, 0.92, 0.85, 0.7)},
	{"sky": Color(0.50, 0.42, 0.78), "pipe": Color(0.30, 0.68, 0.62), "lip": Color(0.20, 0.52, 0.48), "cloud": Color(0.90, 0.85, 1, 0.55)},
	{"sky": Color(0.10, 0.13, 0.30), "pipe": Color(0.30, 0.58, 0.36), "lip": Color(0.20, 0.44, 0.27), "cloud": Color(0.60, 0.65, 0.90, 0.30)},
]


func _ready() -> void:
	randomize()
	font = ThemeDB.fallback_font
	_sb = StyleBoxFlat.new()
	_sb.set_corner_radius_all(14)
	_sb.set_border_width_all(4)
	_load_save()
	_reset()


func _notification(what: int) -> void:
	# make sure coins are never lost if the app is closed or sent to the background
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
		_save()


func _reset() -> void:
	state = State.READY
	y = 450.0
	vel = 0.0
	pipes.clear()
	coin_items.clear()
	spawn_timer = SPAWN_EVERY
	score = 0
	run_coins = 0
	new_best = false
	dead_time = 0.0
	ghost_left = 0.0
	mega_left = 0.0
	mega_s = 1.0
	mega_mult = 1.0
	mega_banner_t = 0.0
	debris.clear()
	pipes_since_pickup = 0
	next_gap_y = randf_range(260.0, GROUND_Y - 260.0)
	lives = MAX_LIVES
	max_lives = MAX_LIVES
	revive_used = false
	level = 1
	speed = PIPE_SPEED
	gap = GAP
	theme_idx = 0
	banner_t = 0.0
	var th0: Dictionary = themes[0]
	col_sky = th0["sky"]
	col_pipe = th0["pipe"]
	col_lip = th0["lip"]
	col_cloud = th0["cloud"]
	invuln_left = 0.0
	shake_t = 0.0
	position = Vector2.ZERO


func _input(event: InputEvent) -> void:
	var pressed := false
	var tap_pos := Vector2(-1.0, -1.0)
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		pressed = true  # touch is converted to mouse clicks automatically
		tap_pos = (make_input_local(event) as InputEventMouseButton).position
	elif event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_SPACE or event.keycode == KEY_UP:
			pressed = true
		elif event.keycode == KEY_M:
			Sfx.set_muted(not Sfx.muted)
	if pressed:
		_on_tap(tap_pos)


func _on_tap(pos: Vector2) -> void:
	match state:
		State.READY:
			if SHOP_BTN.has_point(pos):
				_open_shop()
				return
			if AD_START_BTN.has_point(pos):
				if not bonus_heart:
					Sfx.play("tap")
					_show_rewarded_ad(_grant_bonus_heart)
				return  # tapping the ad button never starts the run by accident
			state = State.PLAYING
			if bonus_heart:  # the extra heart is used up by this run
				bonus_heart = false
				max_lives = MAX_LIVES + 1
				lives = max_lives
			if ghost_charges > 0:  # use a bought Ghost Start charge
				ghost_charges -= 1
				ghost_left = GHOST_TIME
				_save()
			_flap()
		State.PLAYING:
			_flap()
		State.DEAD:
			if dead_time > 0.8:
				Sfx.play("tap")
				if not revive_used and AD_REVIVE_BTN.has_point(pos):
					_show_rewarded_ad(_revive)
				elif SHOP_BTN.has_point(pos):
					_open_shop()
				else:
					_reset()
		State.SHOP:
			_shop_tap(pos)


func _flap() -> void:
	vel = FLAP
	Sfx.play("hop", 0.05)


func _process(delta: float) -> void:
	bob_t += delta
	toast_t = maxf(toast_t - delta, 0.0)
	mega_banner_t = maxf(mega_banner_t - delta, 0.0)
	_update_debris(delta)
	var th: Dictionary = themes[theme_idx]
	var k := 1.0 - exp(-3.0 * delta)
	col_sky = col_sky.lerp(th["sky"], k)
	col_pipe = col_pipe.lerp(th["pipe"], k)
	col_lip = col_lip.lerp(th["lip"], k)
	col_cloud = col_cloud.lerp(th["cloud"], k)
	if shake_t > 0.0:
		shake_t = maxf(shake_t - delta, 0.0)
		position = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * SHAKE_POWER * (shake_t / SHAKE_TIME)
	elif position != Vector2.ZERO:
		position = Vector2.ZERO
	match state:
		State.READY:
			y = 450.0 + sin(bob_t * 4.0) * 10.0
			ground_scroll += PIPE_SPEED * delta
		State.PLAYING:
			_update_playing(delta)
		State.DEAD:
			dead_time += delta
			vel += GRAVITY * delta
			y += vel * delta
			if y > GROUND_Y - RADIUS:
				y = GROUND_Y - RADIUS
				vel = 0.0
		State.SHOP:
			ground_scroll += PIPE_SPEED * delta * 0.5
	queue_redraw()


func _update_playing(delta: float) -> void:
	var was_ghost := ghost_left > 0.0
	var was_mega := mega_left > 0.0
	ghost_left = maxf(ghost_left - delta, 0.0)
	mega_left = maxf(mega_left - delta, 0.0)
	invuln_left = maxf(invuln_left - delta, 0.0)
	if was_ghost and ghost_left <= 0.0:
		invuln_left = maxf(invuln_left, GHOST_END_GRACE)
	if was_mega and mega_left <= 0.0:
		invuln_left = maxf(invuln_left, MEGA_END_GRACE)
	banner_t = maxf(banner_t - delta, 0.0)

	# Mega mode eases Puff's size and the world speed up and back down
	var mega_on := mega_left > 0.0
	mega_mult = move_toward(mega_mult, MEGA_SPEED if mega_on else 1.0, delta * 3.0)
	mega_s = move_toward(mega_s, MEGA_SCALE if mega_on else 1.0, delta * 3.5)
	var cur_speed := speed * mega_mult   # pipes, coins and ground all scroll at this speed
	var r := RADIUS * mega_s             # Puff's current radius

	ground_scroll += cur_speed * delta
	vel += GRAVITY * delta
	y += vel * delta
	if y < r:
		y = r
		vel = 0.0

	spawn_timer += delta * mega_mult   # keeps the distance between pipes the same when sped up
	if spawn_timer >= PIPE_SPACING / speed:
		spawn_timer = 0.0
		_spawn_pipe()

	for p in pipes:
		p["x"] -= cur_speed * delta
		if p["pickup"] and not p["taken"]:
			var pc := Vector2(p["x"] + PIPE_W / 2.0, p["gap_y"])
			if pc.distance_to(Vector2(PLAYER_X, y)) < r + PICKUP_R:
				if p["kind"] == "mega":
					p["taken"] = true
					_start_mega()
				elif mega_left <= 0.0:   # a Ghost pickup is left alone while Mega is active
					p["taken"] = true
					ghost_left = GHOST_TIME
					Sfx.play("score")
		if not p["scored"] and p["x"] + PIPE_W < PLAYER_X - RADIUS:
			p["scored"] = true
			score += 1
			Sfx.play("score")
			_check_level_up()
	pipes = pipes.filter(func(p): return p["x"] > -PIPE_W - 10.0)

	for c in coin_items:
		c["x"] -= cur_speed * delta
		if not c["taken"]:
			var cc := Vector2(c["x"], c["y"])
			if cc.distance_to(Vector2(PLAYER_X, y)) < r + COIN_R:
				c["taken"] = true
				coins += 1
				run_coins += 1
				Sfx.play("coin", 0.06)
	coin_items = coin_items.filter(func(c): return c["x"] > -COIN_R - 10.0 and not c["taken"])

	# Mega mode: anything Puff touches gets smashed instead of hurting
	if mega_left > 0.0:
		for p in pipes:
			if not p["top_gone"] and _circle_hits_rect(PLAYER_X, y, r, _pipe_top_rect(p)):
				_smash_half(p, true)
			if not p["bottom_gone"] and _circle_hits_rect(PLAYER_X, y, r, _pipe_bottom_rect(p)):
				_smash_half(p, false)

	# pipes only hurt when not in ghost/mega mode and not protected after a recent hit
	if ghost_left <= 0.0 and mega_left <= 0.0 and invuln_left <= 0.0:
		for p in pipes:
			var hit := false
			if not p["top_gone"] and _circle_hits_rect(PLAYER_X, y, r - 3.0, _pipe_top_rect(p)):
				hit = true
			elif not p["bottom_gone"] and _circle_hits_rect(PLAYER_X, y, r - 3.0, _pipe_bottom_rect(p)):
				hit = true
			if hit:
				_hit_pipe()
				if state == State.DEAD:
					return
				break  # only one heart per hit

	if y + r >= GROUND_Y:
		y = GROUND_Y - r
		_die()


func _spawn_pipe() -> void:
	pipes_since_pickup += 1
	var has_pickup := false
	var kind := "ghost"
	if pipes_since_pickup >= PICKUP_MIN_PIPES and ghost_left <= 0.0 and mega_left <= 0.0 and randf() < PICKUP_CHANCE:
		has_pickup = true
		pipes_since_pickup = 0
		if randf() < MEGA_SHARE:
			kind = "mega"
	var gap_y := next_gap_y
	next_gap_y = randf_range(260.0, GROUND_Y - 260.0)
	var pipe_x := W + 20.0
	pipes.append({
		"x": pipe_x,
		"gap_y": gap_y,
		"gap": gap,
		"scored": false,
		"pickup": has_pickup,
		"kind": kind,
		"taken": false,
		"top_gone": false,
		"bottom_gone": false,
	})
	# a little trail of coins along the path to the next gap
	var spacing := PIPE_SPEED * SPAWN_EVERY
	for t in COIN_PATH_POINTS:
		coin_items.append({
			"x": pipe_x + PIPE_W / 2.0 + spacing * t,
			"y": lerpf(gap_y, next_gap_y, t),
			"taken": false,
			"spin": t * 7.0,
		})


func _pipe_top_rect(p: Dictionary) -> Rect2:
	var half_gap: float = p["gap"] / 2.0
	return Rect2(p["x"], 0.0, PIPE_W, p["gap_y"] - half_gap)


func _pipe_bottom_rect(p: Dictionary) -> Rect2:
	var half_gap: float = p["gap"] / 2.0
	var bottom_y: float = p["gap_y"] + half_gap
	return Rect2(p["x"], bottom_y, PIPE_W, GROUND_Y - bottom_y)


func _start_mega() -> void:
	mega_left = MEGA_TIME
	ghost_left = 0.0
	mega_banner_t = MEGA_BANNER_TIME
	Sfx.play("mega")


## Smash one half (top or bottom) of a pipe: it disappears in a burst of debris.
func _smash_half(p: Dictionary, is_top: bool) -> void:
	var rect: Rect2
	if is_top:
		p["top_gone"] = true
		rect = _pipe_top_rect(p)
	else:
		p["bottom_gone"] = true
		rect = _pipe_bottom_rect(p)
	for i in 24:
		var py: float
		if i < 14:   # most pieces burst out right where Puff hit
			py = clampf(y + randf_range(-45.0, 45.0), rect.position.y + 4.0, rect.end.y - 4.0)
		else:        # the rest crumble off along the rest of the pipe
			py = randf_range(rect.position.y + 4.0, rect.end.y - 4.0)
		debris.append({
			"x": randf_range(rect.position.x, rect.end.x),
			"y": py,
			"vx": randf_range(-260.0, 160.0),
			"vy": randf_range(-420.0, 80.0),
			"rot": randf_range(0.0, TAU),
			"vr": randf_range(-9.0, 9.0),
			"size": randf_range(7.0, 18.0),
			"life": randf_range(0.6, 1.0),
			"col": col_pipe if randf() < 0.7 else col_lip,
		})
	shake_t = maxf(shake_t, SHAKE_TIME * 0.6)
	Sfx.play("smash", 0.08)


func _update_debris(delta: float) -> void:
	if debris.is_empty():
		return
	for d in debris:
		d["vy"] += DEBRIS_GRAVITY * delta
		d["x"] += d["vx"] * delta
		d["y"] += d["vy"] * delta
		d["rot"] += d["vr"] * delta
		d["life"] -= delta
	debris = debris.filter(func(d): return d["life"] > 0.0 and d["y"] < GROUND_Y + 40.0)


func _circle_hits_rect(cx: float, cy: float, r: float, rect: Rect2) -> bool:
	var nx := clampf(cx, rect.position.x, rect.end.x)
	var ny := clampf(cy, rect.position.y, rect.end.y)
	var dx := cx - nx
	var dy := cy - ny
	return dx * dx + dy * dy < r * r


func _die() -> void:
	state = State.DEAD
	dead_time = 0.0
	ghost_left = 0.0
	mega_left = 0.0
	mega_s = 1.0
	mega_mult = 1.0
	invuln_left = 0.0
	shake_t = 0.0
	vel = -220.0
	Sfx.play("hit")
	get_tree().create_timer(0.25).timeout.connect(func(): Sfx.play("fall"))
	if score > high_score:
		high_score = score
		new_best = true
		get_tree().create_timer(0.5).timeout.connect(func(): Sfx.play("highscore"))
	_save()


func _level_for(s: int) -> int:
	return 1 + floori(float(s) / PIPES_PER_LEVEL)


func _check_level_up() -> void:
	var new_level := _level_for(score)
	if new_level <= level:
		return
	level = new_level
	speed = PIPE_SPEED + minf((level - 1) * LEVEL_SPEED_STEP, MAX_SPEED_BONUS)
	gap = maxf(GAP - (level - 1) * LEVEL_GAP_STEP, MIN_GAP)
	theme_idx = (level - 1) % themes.size()
	banner_t = BANNER_TIME
	coins += LEVEL_COIN_BONUS
	run_coins += LEVEL_COIN_BONUS
	Sfx.play("highscore")


# ---------------------------------------------------------------- rewarded ads
# Real rewarded ads via the AdManager autoload (AdMob). The reward callback runs only
# after the player has watched the ad to the end. On desktop/editor (no ad SDK)
# AdManager grants the reward immediately so you can still test.
var _pending_reward := Callable()


func _show_rewarded_ad(on_reward: Callable) -> void:
	_pending_reward = on_reward
	if not AdManager.reward_earned.is_connected(_on_ad_reward_earned):
		AdManager.reward_earned.connect(_on_ad_reward_earned)
	AdManager.show_rewarded_ad()


func _on_ad_reward_earned() -> void:
	if _pending_reward.is_valid():
		var cb := _pending_reward
		_pending_reward = Callable()
		cb.call()


func _grant_bonus_heart() -> void:
	bonus_heart = true
	Sfx.play("highscore")


func _revive() -> void:
	revive_used = true
	state = State.PLAYING
	lives = 1
	invuln_left = REVIVE_PROTECT
	ghost_left = 0.0
	mega_left = 0.0
	y = 450.0
	vel = FLAP
	Sfx.play("score")


func _hit_pipe() -> void:
	lives -= 1
	if lives <= 0:
		lives = 0
		_die()
		return
	invuln_left = INVULN_TIME
	shake_t = SHAKE_TIME
	vel = HURT_BOUNCE
	Sfx.play("hit")


# ---------------------------------------------------------------- shop

func _open_shop() -> void:
	state = State.SHOP
	toast_text = ""
	toast_t = 0.0


func _item_btn(i: int) -> Rect2:
	return Rect2(ROW_X + ROW_W - 156.0, ROW_Y0 + i * ROW_STEP + 14.0, 140.0, 56.0)


func _shop_tap(pos: Vector2) -> void:
	if BACK_BTN.has_point(pos):
		Sfx.play("tap")
		_reset()
		return
	for i in range(skins.size() + 1):
		if _item_btn(i).has_point(pos):
			_item_action(i)
			return


func _item_action(i: int) -> void:
	if i < skins.size():
		var sk: Dictionary = skins[i]
		var id: String = sk["id"]
		var price: int = sk["price"]
		if owned.has(id):
			equipped = id
			Sfx.play("tap")
			_save()
		elif coins >= price:
			coins -= price
			owned.append(id)
			equipped = id
			Sfx.play("highscore")
			_show_toast("Unlocked %s!" % sk["name"])
			_save()
		else:
			_not_enough()
	else:
		if ghost_charges >= MAX_GHOST_CHARGES:
			Sfx.play("tap")
			_show_toast("You can hold up to %d" % MAX_GHOST_CHARGES)
		elif coins >= GHOST_PRICE:
			coins -= GHOST_PRICE
			ghost_charges += 1
			Sfx.play("highscore")
			_show_toast("Ghost Start added!")
			_save()
		else:
			_not_enough()


func _not_enough() -> void:
	Sfx.play("tap")
	_show_toast("Not enough coins yet")


func _show_toast(s: String) -> void:
	toast_text = s
	toast_t = 1.6


func _equipped_skin() -> Dictionary:
	for sk in skins:
		if sk["id"] == equipped:
			return sk
	return skins[0]


# ---------------------------------------------------------------- saving

func _load_save() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	high_score = cfg.get_value("game", "high_score", 0)
	coins = cfg.get_value("shop", "coins", 0)
	owned = cfg.get_value("shop", "owned", ["bubblegum"])
	equipped = cfg.get_value("shop", "equipped", "bubblegum")
	ghost_charges = cfg.get_value("shop", "ghost_charges", 0)
	if not owned.has("bubblegum"):
		owned.append("bubblegum")
	if not owned.has(equipped):
		equipped = "bubblegum"


func _save() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("game", "high_score", high_score)
	cfg.set_value("shop", "coins", coins)
	cfg.set_value("shop", "owned", owned)
	cfg.set_value("shop", "equipped", equipped)
	cfg.set_value("shop", "ghost_charges", ghost_charges)
	cfg.save(SAVE_PATH)


# ---------------------------------------------------------------- drawing helpers

func _text(s: String, baseline_y: float, size: int) -> void:
	var pos := Vector2(0.0, baseline_y)
	draw_string_outline(font, pos, s, HORIZONTAL_ALIGNMENT_CENTER, W, size, 10, Color.BLACK)
	draw_string(font, pos, s, HORIZONTAL_ALIGNMENT_CENTER, W, size, Color.WHITE)


func _label(s: String, pos: Vector2, size: int, align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT, width := -1.0) -> void:
	draw_string_outline(font, pos, s, align, width, size, 8, Color.BLACK)
	draw_string(font, pos, s, align, width, size, Color.WHITE)


func _panel(rect: Rect2, fill: Color, border: Color) -> void:
	_sb.bg_color = fill
	_sb.border_color = border
	draw_style_box(_sb, rect)


func _button(rect: Rect2, fill: Color, label: String, size: int, show_coin := false) -> void:
	_panel(rect, fill, fill.darkened(0.35))
	var mid_y := rect.position.y + rect.size.y / 2.0
	var left := rect.position.x
	var w := rect.size.x
	if show_coin:
		_draw_coin(Vector2(left + 30.0, mid_y), 13.0, 0.0)
		left += 24.0
		w -= 24.0
	_label(label, Vector2(left, mid_y + size * 0.35), size, HORIZONTAL_ALIGNMENT_CENTER, w)


func _draw_coin(c: Vector2, r: float, spin: float) -> void:
	var sx := maxf(absf(cos(spin)), 0.25)
	draw_set_transform(c, 0.0, Vector2(sx, 1.0))
	draw_circle(Vector2.ZERO, r, Color(0.80, 0.55, 0.05))
	draw_circle(Vector2.ZERO, r - 3.0, Color(1.0, 0.82, 0.15))
	draw_circle(Vector2(-r * 0.25, -r * 0.25), r * 0.22, Color(1.0, 1.0, 0.85, 0.9))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _coin_counter(pos: Vector2, txt: String, size: int, centered := false) -> void:
	var r := size * 0.4
	var tw := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	var total := r * 2.0 + 10.0 + tw
	var x := pos.x
	if centered:
		x = pos.x - total / 2.0
	_draw_coin(Vector2(x + r, pos.y), r, bob_t * 3.0)
	_label(txt, Vector2(x + r * 2.0 + 10.0, pos.y + size * 0.35), size)


func _draw_ghost_icon(gc: Vector2, s: float) -> void:
	draw_circle(gc, (PICKUP_R + 5.0) * s, Color(1, 1, 1, 0.45))
	draw_circle(gc, PICKUP_R * s, Color(0.68, 0.55, 1.0))
	draw_circle(gc + Vector2(-6, -4) * s, 4.0 * s, Color.WHITE)
	draw_circle(gc + Vector2(6, -4) * s, 4.0 * s, Color.WHITE)
	draw_circle(gc + Vector2(-6, -3) * s, 2.0 * s, Color.BLACK)
	draw_circle(gc + Vector2(6, -3) * s, 2.0 * s, Color.BLACK)
	draw_circle(gc + Vector2(0, 7) * s, 4.0 * s, Color(0.35, 0.2, 0.6))


func _draw_mega_icon(gc: Vector2, s: float) -> void:
	draw_circle(gc, (PICKUP_R + 5.0) * s, Color(1, 1, 1, 0.45))
	draw_circle(gc, PICKUP_R * s, Color(1.0, 0.55, 0.15))
	draw_circle(gc, PICKUP_R * s * 0.74, Color(1.0, 0.82, 0.28))
	var bolt := Color(0.60, 0.18, 0.05)   # lightning bolt made of two triangles
	draw_colored_polygon(PackedVector2Array([gc + Vector2(4, -13) * 0.8 * s, gc + Vector2(-7, 2) * 0.8 * s, gc + Vector2(0, 2) * 0.8 * s]), bolt)
	draw_colored_polygon(PackedVector2Array([gc + Vector2(-4, 13) * 0.8 * s, gc + Vector2(7, -2) * 0.8 * s, gc + Vector2(0, -2) * 0.8 * s]), bolt)


func _heart_shape(c: Vector2, s: float, col: Color) -> void:
	var r := s * 0.27
	draw_circle(c + Vector2(-0.24, -0.12) * s, r, col)
	draw_circle(c + Vector2(0.24, -0.12) * s, r, col)
	draw_colored_polygon(PackedVector2Array([
		c + Vector2(-0.50, -0.02) * s,
		c + Vector2(0.50, -0.02) * s,
		c + Vector2(0.0, 0.50) * s,
	]), col)


func _draw_heart(c: Vector2, s: float, filled: bool) -> void:
	if filled:
		_heart_shape(c, s + 7.0, Color(0.45, 0.05, 0.12))   # outline
		_heart_shape(c, s, Color(0.95, 0.22, 0.32))
		draw_circle(c + Vector2(-0.28, -0.20) * s, s * 0.08, Color(1, 1, 1, 0.8))
	else:
		_heart_shape(c, s + 7.0, Color(0, 0, 0, 0.45))
		_heart_shape(c, s, Color(0.25, 0.25, 0.32, 0.7))


func _draw_hearts() -> void:
	for i in max_lives:
		var cx := W - 40.0 - (max_lives - 1 - i) * 46.0
		_draw_heart(Vector2(cx, 46.0), 34.0, i < lives)


func _draw_puff(pos: Vector2, skin: Dictionary, a: float, s: float) -> void:
	var body: Color = skin["body"]
	var wing: Color = skin["wing"]
	var cheek: Color = skin["cheek"]
	body.a = a
	wing.a = a
	cheek.a = a
	draw_circle(pos, RADIUS * s, body)
	draw_circle(pos + Vector2(-8, 6) * s, 10.0 * s, wing)            # wing
	draw_circle(pos + Vector2(9, -7) * s, 8.0 * s, Color(1, 1, 1, a))  # eye
	draw_circle(pos + Vector2(11, -7) * s, 4.0 * s, Color(0, 0, 0, a))
	draw_circle(pos + Vector2(14, 6) * s, 5.0 * s, cheek)            # cheek


func _draw_sky() -> void:
	draw_rect(Rect2(-20, -20, W + 40, H + 40), col_sky)
	# slow clouds
	for i in 4:
		var cx := fposmod(i * 220.0 - ground_scroll * 0.15, W + 200.0) - 100.0
		var cy := 140.0 + i * 90.0
		draw_circle(Vector2(cx, cy), 34, col_cloud)
		draw_circle(Vector2(cx + 34, cy + 8), 28, col_cloud)
		draw_circle(Vector2(cx - 32, cy + 10), 24, col_cloud)


func _draw_shop() -> void:
	_text("Shop", 100, 72)
	_coin_counter(Vector2(W / 2.0, 160.0), str(coins), 48, true)

	for i in range(skins.size() + 1):
		var row := Rect2(ROW_X, ROW_Y0 + i * ROW_STEP, ROW_W, ROW_H)
		_panel(row, Color(0, 0, 0, 0.35), Color(1, 1, 1, 0.3))
		var cy := row.position.y + ROW_H / 2.0
		var btn := _item_btn(i)
		var icon_pos := Vector2(row.position.x + 50.0, cy)
		var name_x := row.position.x + 100.0
		if i < skins.size():
			var sk: Dictionary = skins[i]
			var id: String = sk["id"]
			var price: int = sk["price"]
			_draw_puff(icon_pos, sk, 1.0, 1.0)
			_label(sk["name"], Vector2(name_x, cy + 11.0), 32)
			if id == equipped:
				_button(btn, Color(0.40, 0.78, 0.40), "Equipped", 26)
			elif owned.has(id):
				_button(btn, Color(0.35, 0.65, 1.0), "Equip", 30)
			elif coins >= price:
				_button(btn, Color(1.0, 0.72, 0.15), str(price), 32, true)
			else:
				_button(btn, Color(0.55, 0.55, 0.62), str(price), 32, true)
		else:
			_draw_ghost_icon(icon_pos, 1.2)
			_label("Ghost Start", Vector2(name_x, cy - 2.0), 32)
			_label("Owned: %d" % ghost_charges, Vector2(name_x, cy + 26.0), 24)
			if ghost_charges >= MAX_GHOST_CHARGES:
				_button(btn, Color(0.55, 0.55, 0.62), "Full", 30)
			elif coins >= GHOST_PRICE:
				_button(btn, Color(1.0, 0.72, 0.15), str(GHOST_PRICE), 32, true)
			else:
				_button(btn, Color(0.55, 0.55, 0.62), str(GHOST_PRICE), 32, true)

	if toast_t > 0.0:
		_text(toast_text, 792, 30)
	_button(BACK_BTN, Color(0.95, 0.45, 0.50), "Back", 36)


func _draw() -> void:
	_draw_sky()
	if state == State.SHOP:
		_draw_shop()
		return

	# pipes
	var pipe_col := col_pipe
	var lip_col := col_lip
	for p in pipes:
		var x: float = p["x"]
		var top_h: float = p["gap_y"] - p["gap"] / 2.0
		var bottom_y: float = p["gap_y"] + p["gap"] / 2.0
		if not p["top_gone"]:
			draw_rect(Rect2(x, 0, PIPE_W, top_h), pipe_col)
			draw_rect(Rect2(x - 8, top_h - 32, PIPE_W + 16, 32), lip_col)
		if not p["bottom_gone"]:
			draw_rect(Rect2(x, bottom_y, PIPE_W, GROUND_Y - bottom_y), pipe_col)
			draw_rect(Rect2(x - 8, bottom_y, PIPE_W + 16, 32), lip_col)
		if p["pickup"] and not p["taken"]:
			var icon_c := Vector2(x + PIPE_W / 2.0, p["gap_y"] + sin(bob_t * 5.0) * 5.0)
			if p["kind"] == "mega":
				_draw_mega_icon(icon_c, 1.0)
			else:
				_draw_ghost_icon(icon_c, 1.0)

	# coins
	for c in coin_items:
		if not c["taken"]:
			_draw_coin(Vector2(c["x"], c["y"]), COIN_R, bob_t * 5.0 + float(c["spin"]))

	# smashed pipe pieces
	for d in debris:
		var dc: Color = d["col"]
		dc.a = clampf(float(d["life"]) / 0.35, 0.0, 1.0)
		var sz: float = d["size"]
		draw_set_transform(Vector2(d["x"], d["y"]), d["rot"], Vector2.ONE)
		draw_rect(Rect2(-sz / 2.0, -sz / 2.0, sz, sz), dc)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

	# ground
	draw_rect(Rect2(-20, GROUND_Y, W + 40, H - GROUND_Y + 20), Color(0.87, 0.78, 0.50))
	draw_rect(Rect2(-20, GROUND_Y, W + 40, 16), Color(0.45, 0.80, 0.30))
	for i in range(-1, 13):
		draw_rect(Rect2(i * 50.0 - fposmod(ground_scroll, 50.0), GROUND_Y + 16, 25, 10), Color(0.40, 0.72, 0.27))

	# Puff
	var a := 1.0
	if ghost_left > 0.0:
		a = 0.4
		if ghost_left < 1.0 and int(ghost_left * 10.0) % 2 == 0:
			a = 0.9  # blink: ghost mode is about to end
	elif invuln_left > 0.0 and int(invuln_left * 12.0) % 2 == 0:
		a = 0.3  # blink while protected after losing a heart
	if mega_left > 0.0:
		var pulse := 1.0 + sin(bob_t * 14.0) * 0.06
		draw_circle(Vector2(PLAYER_X, y), RADIUS * mega_s * 1.45 * pulse, Color(1.0, 0.60, 0.15, 0.30))
		for i in 5:   # speed lines trailing behind
			var ly := y + (i - 2) * 22.0 * mega_s
			var lx := PLAYER_X - 46.0 * mega_s - fposmod(bob_t * 700.0 + i * 53.0, 90.0)
			draw_line(Vector2(lx, ly), Vector2(lx - 42.0, ly), Color(1, 1, 1, 0.55), 4.0)
		a = 1.0
		if mega_left < 1.0 and int(mega_left * 10.0) % 2 == 0:
			a = 0.6  # blink: Mega mode is about to end
	_draw_puff(Vector2(PLAYER_X, y), _equipped_skin(), a, mega_s)

	# text
	match state:
		State.READY:
			_text("Puff Hop", 260, 72)
			_text("Tap to start", 700, 44)
			_button(SHOP_BTN, Color(1.0, 0.72, 0.15), "Shop", 36)
			if bonus_heart:
				_button(AD_START_BTN, Color(0.40, 0.78, 0.40), "Extra heart ready!", 30)
			else:
				if AdManager.is_ad_ready():
					_button(AD_START_BTN, Color(0.55, 0.40, 0.95), "Watch ad: +1 heart", 30)
				else:
					_button(AD_START_BTN, Color(0.55, 0.55, 0.60), "Ad loading...", 30)
			_coin_counter(Vector2(20.0, 46.0), str(coins), 40)
			if ghost_charges > 0:
				_draw_ghost_icon(Vector2(36.0, 104.0), 1.0)
				_label("x%d" % ghost_charges, Vector2(70.0, 115.0), 32)
		State.PLAYING:
			_text(str(score), 160, 96)
			_coin_counter(Vector2(20.0, 46.0), str(run_coins), 40)
			_label("Level %d" % level, Vector2(20.0, 100.0), 28)
			_draw_hearts()
			if banner_t > 0.0:
				_text("Level %d" % level, 330, 72)
				_text("+%d coins" % LEVEL_COIN_BONUS, 385, 36)
			if ghost_left > 0.0:
				draw_rect(Rect2(W / 2.0 - 82, 188, 164, 16), Color(0, 0, 0, 0.5))
				draw_rect(Rect2(W / 2.0 - 80, 190, 160.0 * ghost_left / GHOST_TIME, 12), Color(0.68, 0.55, 1.0))
			if mega_left > 0.0:
				draw_rect(Rect2(W / 2.0 - 82, 188, 164, 16), Color(0, 0, 0, 0.5))
				draw_rect(Rect2(W / 2.0 - 80, 190, 160.0 * mega_left / MEGA_TIME, 12), Color(1.0, 0.60, 0.15))
			if mega_banner_t > 0.0:
				_text("MEGA!", 270, 80)
		State.DEAD:
			_text("Game Over", 300, 72)
			_text("Score: %d  (Level %d)" % [score, level], 390, 44)
			_text("Best: %d" % high_score, 450, 48)
			if new_best:
				_text("NEW BEST!", 520, 52)
			_coin_counter(Vector2(W / 2.0, 600.0), "+%d" % run_coins, 44, true)
			_coin_counter(Vector2(20.0, 46.0), str(coins), 40)
			if dead_time > 0.8:
				if revive_used:
					_text("Tap to retry", 700, 44)
				else:
					if AdManager.is_ad_ready():
						_button(AD_REVIVE_BTN, Color(0.55, 0.40, 0.95), "Watch ad to continue", 30)
					else:
						_button(AD_REVIVE_BTN, Color(0.55, 0.55, 0.60), "Ad loading...", 30)
					_text("Tap to retry", 735, 40)
				_button(SHOP_BTN, Color(1.0, 0.72, 0.15), "Shop", 36)
