extends Node
## Autoload sound manager. Call Sfx.play("hop") from any script.

const SOUNDS := {
	"hop": preload("res://audio/sfx/hop.wav"),
	"score": preload("res://audio/sfx/score.wav"),
	"hit": preload("res://audio/sfx/hit.wav"),
	"fall": preload("res://audio/sfx/fall.wav"),
	"highscore": preload("res://audio/sfx/highscore.wav"),
	"tap": preload("res://audio/sfx/tap.wav"),
	"coin": preload("res://audio/sfx/coin.wav"),
	"smash": preload("res://audio/sfx/smash.wav"),
	"mega": preload("res://audio/sfx/mega.wav"),
}

const POOL_SIZE := 6
var muted := false
var _players: Array[AudioStreamPlayer] = []
var _next := 0

func _ready() -> void:
	for i in POOL_SIZE:
		var p := AudioStreamPlayer.new()
		add_child(p)
		_players.append(p)

func play(sound_name: String, pitch_variation := 0.0) -> void:
	if muted or not SOUNDS.has(sound_name):
		return
	var p := _players[_next]
	_next = (_next + 1) % POOL_SIZE
	p.stream = SOUNDS[sound_name]
	p.pitch_scale = 1.0 + randf_range(-pitch_variation, pitch_variation)
	p.play()

func set_muted(value: bool) -> void:
	muted = value
