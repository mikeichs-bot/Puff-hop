# Godot 4.7 AdMob Plugin (Fixed Version) 🚀
*Provided by [aioapp.at](https://aioapp.at)*

🇬🇧 **English:**
This is a fixed version of the Poing Studios AdMob Plugin. It resolves the fatal Gradle export crash where `play-services-ads` is blocked during the build process.

**How to install:**
1. Copy this `admob` folder into your `res://addons/` directory.
2. Enable it in the Godot Project Settings.
3. Add your AdMob App-ID to your Android Manifest.

---

🇩🇪 **Deutsch:**
Dies ist eine reparierte Version des AdMob-Plugins. Sie behebt den fatalen Absturz beim Gradle-Export, bei dem die Google-Ads-Bibliothek blockiert wird.

**Installation:**
1. Kopiere diesen `admob` Ordner in dein `res://addons/` Verzeichnis.
2. Aktiviere das Plugin in den Projekteinstellungen.
3. Trage deine AdMob App-ID in das Android Manifest ein.