extends Control
## Sound test screen: one button per sound, plus a mute toggle.

func _ready() -> void:
	var box := VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_FULL_RECT)
	box.offset_left = 60
	box.offset_right = -60
	box.offset_top = 120
	box.add_theme_constant_override("separation", 24)
	add_child(box)

	var title := Label.new()
	title.text = "Puff Hop - Sound Test"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(title)

	for sound_name in ["hop", "score", "hit", "fall", "highscore", "tap"]:
		var b := Button.new()
		b.text = sound_name.capitalize()
		b.custom_minimum_size = Vector2(0, 80)
		b.pressed.connect(func(): Sfx.play(sound_name, 0.05 if sound_name == "hop" else 0.0))
		box.add_child(b)

	var mute := CheckButton.new()
	mute.text = "Mute"
	mute.custom_minimum_size = Vector2(0, 80)
	mute.toggled.connect(func(on: bool): Sfx.set_muted(on))
	box.add_child(mute)
