extends Node
## AdManager (autoload) - rewarded ad for the "extra heart" button.
## Add in Project Settings > Globals (Autoload) as "AdManager".
##
## Usage from your game:
##   AdManager.reward_earned.connect(_on_extra_heart)      # grant the heart here
##   AdManager.ad_ready_changed.connect(_on_ad_ready)      # enable/disable the button
##   watch_ad_button.pressed.connect(AdManager.show_rewarded_ad)

signal reward_earned
signal ad_ready_changed(is_ready: bool)

# Google's official TEST ad unit IDs (safe to tap). Used in debug builds.
const TEST_ANDROID := "ca-app-pub-3940256099942544/5224354917"
const TEST_IOS := "ca-app-pub-3940256099942544/1712485313"

# Paste your REAL rewarded ad unit IDs from AdMob here before release.
const REAL_ANDROID := "ca-app-pub-4854007477106172/5631847966"
const REAL_IOS := ""

var _ad: RewardedAd = null
var _loading := false
var _earned := false

var _load_callback := RewardedAdLoadCallback.new()
var _content_callback := FullScreenContentCallback.new()
var _reward_listener := OnUserEarnedRewardListener.new()


func _ready() -> void:
	if not _is_mobile():
		return # Editor/desktop: no ad SDK, show_rewarded_ad() grants the reward directly.

	_load_callback.on_ad_loaded = _on_ad_loaded
	_load_callback.on_ad_failed_to_load = _on_ad_failed_to_load
	_reward_listener.on_user_earned_reward = _on_user_earned_reward
	_content_callback.on_ad_dismissed_full_screen_content = _on_ad_dismissed
	_content_callback.on_ad_failed_to_show_full_screen_content = _on_ad_failed_to_show

	_start_consent()


# --- consent (GDPR/UMP) then SDK init ----------------------------------------

var _sdk_started := false


func _start_consent() -> void:
	var request := ConsentRequestParameters.new()
	UserMessagingPlatform.consent_information.update(
		request, _on_consent_info_ok, func(_e: FormError) -> void: _init_sdk())


func _on_consent_info_ok() -> void:
	if UserMessagingPlatform.consent_information.get_is_consent_form_available():
		UserMessagingPlatform.load_consent_form(_on_consent_form_loaded,
			func(_e: FormError) -> void: _init_sdk())
	else:
		_init_sdk()


func _on_consent_form_loaded(form: ConsentForm) -> void:
	var status := UserMessagingPlatform.consent_information.get_consent_status()
	if status == ConsentInformation.ConsentStatus.REQUIRED:
		form.show(func(_e: FormError) -> void: _init_sdk())
	else:
		_init_sdk()


func _init_sdk() -> void:
	if _sdk_started:
		return
	_sdk_started = true
	var init_listener := OnInitializationCompleteListener.new()
	init_listener.on_initialization_complete = func(_status: InitializationStatus) -> void:
		load_rewarded_ad()
	MobileAds.initialize(init_listener)


func is_ad_ready() -> bool:
	return _ad != null or not _is_mobile()


func load_rewarded_ad() -> void:
	if not _is_mobile() or _loading or _ad != null or _unit_id().is_empty():
		return
	_loading = true
	RewardedAdLoader.new().load(_unit_id(), AdRequest.new(), _load_callback)


func show_rewarded_ad() -> void:
	if not _is_mobile():
		reward_earned.emit() # placeholder behaviour for testing on desktop
		return
	if _ad == null:
		load_rewarded_ad() # not ready yet; try again for next tap
		return
	_earned = false
	_ad.show(_reward_listener)


# --- callbacks ---------------------------------------------------------------

func _on_ad_loaded(ad: RewardedAd) -> void:
	_loading = false
	ad.full_screen_content_callback = _content_callback
	_ad = ad
	ad_ready_changed.emit(true)


func _on_ad_failed_to_load(error: LoadAdError) -> void:
	_loading = false
	push_warning("AdMob: rewarded ad failed to load: " + error.message)
	ad_ready_changed.emit(false)


func _on_user_earned_reward(_item: RewardedItem) -> void:
	_earned = true # grant after the ad closes, so game state isn't changed mid-ad


func _on_ad_dismissed() -> void:
	_destroy_ad()
	if _earned:
		_earned = false
		reward_earned.emit()
	load_rewarded_ad() # preload the next one


func _on_ad_failed_to_show(error: AdError) -> void:
	push_warning("AdMob: rewarded ad failed to show: " + error.message)
	_destroy_ad()
	load_rewarded_ad()


# --- helpers -----------------------------------------------------------------

func _destroy_ad() -> void:
	if _ad:
		_ad.destroy()
		_ad = null
	ad_ready_changed.emit(false)


func _is_mobile() -> bool:
	var os_name := OS.get_name()
	return os_name == "Android" or os_name == "iOS"


func _unit_id() -> String:
	var is_android := OS.get_name() == "Android"
	if OS.is_debug_build():
		return TEST_ANDROID if is_android else TEST_IOS
	# Release build: real IDs only. If one is missing, show no ads (never ship test ads).
	var real := REAL_ANDROID if is_android else REAL_IOS
	if real.is_empty():
		push_warning("AdMob: no real ad unit ID set for this platform, ads disabled.")
	return real
